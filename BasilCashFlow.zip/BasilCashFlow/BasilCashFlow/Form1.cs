﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BasilCashFlow
{
    public partial class txt2Hourr : Form
    {

        public txt2Hourr()
        {
            InitializeComponent();
            
        }

        private void frmMain(object sender, EventArgs e)
        {
            
        }

        private void txtSave_Click(object sender, EventArgs e)
        {            
            
                        
        }

        private void btnPrint_Click(object sender, EventArgs e)
        {
            double Wage = 0;
            double Hours = 0;
            double Hours2 = 0;
            double Salary = 0;
            double Salary2 = 0;
            double Quan = 0;
            double Quan2 = 0;
            double Price2 = 0;
            double Price = 0;
            double Wage2 = 0;
            double TotalI;
            double TotalI2;
            double TotalI3;
            double Total;
            string EmployeeS = txtEmployeeS.Text;
            string SSNS = txt2SSNS.Text;
            string EmployeeS2 = txt2EmployeeS2.Text;
            string SSNS2 = txt2SSNS2.Text;
            string EmployeeH = txt2EmployeeH.Text;
            string EmployeeH2 = txt2EmployeeH2.Text;
            string SSNH = txt2SSNH.Text;
            string SSNH2 = txt2SSNH2.Text;
            string Invoice = txt2Invoice.Text;
            string Invoice2 = txt2Invoice2.Text;
            string Part = txt2Price.Text;
            string Part2 = txt2Price2.Text;
            if (txt2Wage.Text != null && txt2Wage.Text != "")
            {
                Wage = Double.Parse(txt2Wage.Text);
            }
            if (txt2Wage2.Text != null && txt2Wage2.Text != "")
            {
                Wage2 = Double.Parse(txt2Wage2.Text);
            }
            if (txt2Hour.Text != null && txt2Hour.Text != "")
            {
                Hours = Double.Parse(txt2Hour.Text);
            }
            if (txt2Hour2.Text != null && txt2Hour2.Text != "")
            {
                Hours2 = Double.Parse(txt2Hour2.Text);
            }
            if (txt2Quan.Text != null && txt2Quan.Text != "")
            {
                Quan = Double.Parse(txt2Quan.Text);
            }
            if (txt2Quan2.Text != null && txt2Quan2.Text != "")
            {
                Quan2 = Double.Parse(txt2Quan.Text);
            }
            if (txt2Price.Text != null && txt2Price.Text != "")
            {
                Price = Double.Parse(txt2Price.Text);
            }
            if (txt2Price2.Text != null && txt2Price2.Text != "")
            {
                Price2 = Double.Parse(txt2Price2.Text);
            }
            if (txt2Salary.Text != null && txt2Salary.Text != "")
            {
                Salary = Double.Parse(txt2Salary.Text);
            }
            if (txt2Salary2.Text != null && txt2Salary2.Text != "")
            {
                Salary2 = Double.Parse(txt2Salary2.Text);
            }                
            double TotalS;
            double TotalH = Wage * Hours;
            double TotalH2 = Wage2 * Hours2;
            double TotalH3 = TotalH + TotalH2;
            TotalS = Salary + Salary2;
            TotalI = Price * Quan;
            TotalI2 = Price2 * Quan2;
            TotalI3 = TotalI + TotalI2;
            Total = TotalH + TotalH2 + TotalI2 + TotalI + Salary + Salary2;
            MessageBox.Show("Weekly Cash Flow Analysis is as follows:\n" + "\n\nSalaried Employee:" + EmployeeS + "\nSocial Security #:" + SSNS +  "\nWeekly Salary:" + "$" + Salary +  "\nEarned:" + "$" + Salary + "\n\nSalaried Employee:" + EmployeeS2  + "\nSocial Security #:" + SSNS2  + "\nWeekly Salary:" + "$" + Salary2 +   "\nEarned" + "$" + Salary2 + "\n" + "\nHourly Employee:" + EmployeeH  + "\nSocial Security #:" + SSNH + "\nHourly Wage Salary:" + "$" + Wage +  "\nHours Worked:" + Hours +  "\nTotal Earned:" + "$" + TotalH +  "\n\nHourly Employee:" + EmployeeH2 +  "\nSSN:" + SSNH2 +  "\nHourly Wage:" + "$" + Wage +  "\nHours Worked:" + Hours2 +  "\n Total Earned:" + "$" + TotalH2 +  "\n\nInvoice:" + Invoice +  "\nQuantity:" + Quan +  "\nPart Description:" + Part +  "\nUnit Price:" + "$" + Price +  "\nExtended Price:" + "$" + TotalI +  "\n\nInvoice" + Invoice +  "\nQuanity:" + Quan2 +  "\nPart Description:" + Part2 +  "\nUnit Price:" + "$" + Price2 +  "\nExtended Price:" + "$" + TotalI2 +  "\nTotal Weekly Payout:" + "$" + Total +  "\n\nCategory Specifics:" + "\nInvoices:" + "$" + TotalI3 +  "\nSalaried Payroll:" + "$" + TotalS +  "\nHourly Payroll:" + "$" + TotalH3); 
        }

        private void txtInvoiceQuan_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void txtInvoice_TextChanged(object sender, EventArgs e)
        {

        }

        private void radSalary_CheckedChanged(object sender, EventArgs e)
        {
            txtInvoice.Visible = false;
            txtInvoiceQuan.Visible = false;
            txtPartDesc.Visible = false;
            txtUnitPrice.Visible = false;
            txtEmployeeS.Visible = true;
            txtSSNS.Visible = true;
            txtSalary.Visible = true;
            lbl1.Visible = true;
            lbl2.Visible = true;
            lbl3.Visible = true;
            lbl4.Visible = true;
            txtEmployeeH.Visible = false;
            txtSSNH.Visible = false;
            txtWage.Visible = false;
            txtHour.Visible = false;
            txtEmployeeS.Enabled = true;
            txtSSNS.Enabled = true;
            txtSalary.Enabled = true;
            txtInvoice.Enabled = false;
            txtInvoiceQuan.Enabled = false;
            txtPartDesc.Enabled = false;
            txtUnitPrice.Enabled = false;
            btnSalary.Enabled = true;
            btnSalary.Visible = true;
            btnHours.Enabled = false;
            btnHours.Visible = false;
            btnInvoice.Enabled = false;
            btnInvoice.Visible = false;
            grpLabels.Visible = true;
        }

        private void radInvoice_CheckedChanged(object sender, EventArgs e)
        {
            txtInvoice.Enabled = true;
            txtInvoiceQuan.Enabled = true;
            txtPartDesc.Enabled = true;
            txtUnitPrice.Enabled = true;
            txtEmployeeH.Visible = false;
            txtSSNH.Visible = false;
            txtWage.Visible = false;
            txtHour.Visible = false;
            txtEmployeeS.Visible = false;
            txtSSNS.Visible = false;
            txtSalary.Visible = false;
            txtInvoice.Visible = true;
            txtInvoiceQuan.Visible = true;
            txtPartDesc.Visible = true;
            txtUnitPrice.Visible = true;
            lbl1.Visible = true;
            lbl2.Visible = true;
            lbl3.Visible = true;
            lbl4.Visible = true;
            txtEmployeeS.Enabled = false;
            txtSSNS.Enabled = false;
            txtSalary.Enabled = false;
            btnInvoice.Enabled = true;
            btnInvoice.Visible = true;
            btnSalary.Enabled = false;
            btnSalary.Visible = false;
            btnHours.Enabled = false;
            btnHours.Visible = false;
            grpLabels.Visible = true;
        }

        private void radHourly_CheckedChanged(object sender, EventArgs e)
        {
            txtInvoice.Enabled = false;
            txtInvoiceQuan.Enabled = false;
            txtPartDesc.Enabled = false;
            txtUnitPrice.Enabled = false;
            txtEmployeeS.Visible = false;
            txtSSNS.Visible = false;
            txtSalary.Visible = false;
            txtEmployeeH.Visible = true;
            txtSSNH.Visible = true;
            txtWage.Visible = true;
            txtHour.Visible = true;
            txtInvoice.Visible = false;
            txtInvoiceQuan.Visible = false;
            txtPartDesc.Visible = false;
            txtUnitPrice.Visible = false;
            lbl1.Visible = true;
            lbl2.Visible = true;
            lbl3.Visible = true;
            lbl4.Visible = true;
            txtEmployeeS.Enabled = false;
            txtSSNS.Enabled = false;
            txtSalary.Enabled = false;
            txtHour.Enabled = true;
            txtEmployeeH.Enabled = true;
            txtSSNH.Enabled = true;
            txtWage.Enabled = true;
            btnHours.Enabled = true;
            btnHours.Visible = true;
            btnSalary.Enabled = false;
            btnSalary.Visible = false;
            btnInvoice.Enabled = false;
            btnInvoice.Visible = false;
            grpLabels.Visible = true;
        }

        private void btnSalary_Click(object sender, EventArgs e)
        {
            if (txtCheckSal.Text == "")
            {
                txt2EmployeeS2.Text = txtEmployeeS.Text;
                txt2SSNS2.Text = txtSSNS.Text;
                txt2Salary2.Text = txtSalary.Text;
                txtEmployeeS.Text = "";
                txtSSNS.Text = "";
                txtSalary.Text = "";
                txtCheckSal.Text = "69";
            }
                
            else if (txtCheckSal.Text == "69")
            {
                txt2EmployeeS.Text = txtEmployeeS.Text;
                txt2SSNS.Text = txtSSNS.Text;
                txt2Salary.Text = txtSalary.Text;            
                txtEmployeeS.Text = "";
                txtSSNS.Text = "";
                txtSalary.Text = "";                    
            }
                    
            
                
        }

        private void btnHourly_Click(object sender, EventArgs e)
        {

            if (txtCheckInvoice.Text == "")
            {
                txt2Invoice.Text = txtInvoice.Text;
                txt2Quan.Text = txtInvoiceQuan.Text;
                txt2Part.Text = txtPartDesc.Text;
                txt2Price.Text = txtUnitPrice.Text;
                txtInvoice.Text = "";
                txtInvoiceQuan.Text = "";
                txtPartDesc.Text = "";
                txtUnitPrice.Text = "";
                txtCheckInvoice.Text = "69";
                
            }
                
            else if (txtCheckInvoice.Text == "69")
            {
                txt2Invoice2.Text = txtInvoice.Text;
                txt2Quan2.Text = txtInvoiceQuan.Text;
                txt2Part2.Text = txtPartDesc.Text;
                txt2Price2.Text = txtUnitPrice.Text;
                txtInvoice.Text = "";
                txtInvoiceQuan.Text = "";
                txtPartDesc.Text = "";
                txtUnitPrice.Text = "";
                txtCheckInvoice.Text = "69";
            }

        }

        private void txtEmployeeH_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnHours_Click(object sender, EventArgs e)
        {

            if (txtCheckHourly.Text == "")
            {
                txt2Hour2.Text = txtHour.Text;
                txt2EmployeeH2.Text = txtEmployeeH.Text;
                txt2SSNH2.Text = txtSSNH.Text;
                txt2Wage2.Text = txtWage.Text;
                txtEmployeeH.Text = "";
                txtHour.Text = "";
                txtSSNH.Text = "";
                txtWage.Text = "";
                txtCheckHourly.Text = "69";
            }
            else if (txtCheckHourly.Text =="69")
            {
                txt2Hour.Text = txtHour.Text;
                txt2EmployeeH.Text = txtEmployeeH.Text;
                txt2SSNH.Text = txtSSNH.Text;
                txt2Wage.Text = txtWage.Text;
                txtEmployeeH.Text = "";
                txtHour.Text = "";
                txtSSNH.Text = "";
                txtWage.Text = "";

            }
            
        }

        private void txtPrint_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
