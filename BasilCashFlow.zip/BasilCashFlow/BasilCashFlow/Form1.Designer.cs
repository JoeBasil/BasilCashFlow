﻿namespace BasilCashFlow
{
    partial class txt2Hourr
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtEmployeeS = new System.Windows.Forms.TextBox();
            this.txtEmployeeH = new System.Windows.Forms.TextBox();
            this.txtInvoice = new System.Windows.Forms.TextBox();
            this.lbl1 = new System.Windows.Forms.Label();
            this.btnPrint = new System.Windows.Forms.Button();
            this.txtSSNS = new System.Windows.Forms.TextBox();
            this.txtSSNH = new System.Windows.Forms.TextBox();
            this.txtInvoiceQuan = new System.Windows.Forms.TextBox();
            this.lbl2 = new System.Windows.Forms.Label();
            this.txtSalary = new System.Windows.Forms.TextBox();
            this.txtWage = new System.Windows.Forms.TextBox();
            this.txtPartDesc = new System.Windows.Forms.TextBox();
            this.lbl3 = new System.Windows.Forms.Label();
            this.txtHour = new System.Windows.Forms.TextBox();
            this.txtUnitPrice = new System.Windows.Forms.TextBox();
            this.lbl4 = new System.Windows.Forms.Label();
            this.radSalary = new System.Windows.Forms.RadioButton();
            this.radInvoice = new System.Windows.Forms.RadioButton();
            this.radHourly = new System.Windows.Forms.RadioButton();
            this.btnSalary = new System.Windows.Forms.Button();
            this.btnInvoice = new System.Windows.Forms.Button();
            this.txt2EmployeeS = new System.Windows.Forms.TextBox();
            this.txt2EmployeeS2 = new System.Windows.Forms.TextBox();
            this.txt2SSNS = new System.Windows.Forms.TextBox();
            this.txt2SSNS2 = new System.Windows.Forms.TextBox();
            this.txt2Salary = new System.Windows.Forms.TextBox();
            this.txt2Salary2 = new System.Windows.Forms.TextBox();
            this.txt2Invoice = new System.Windows.Forms.TextBox();
            this.txt2Invoice2 = new System.Windows.Forms.TextBox();
            this.txt2Quan = new System.Windows.Forms.TextBox();
            this.txt2Quan2 = new System.Windows.Forms.TextBox();
            this.txt2Part = new System.Windows.Forms.TextBox();
            this.txt2Part2 = new System.Windows.Forms.TextBox();
            this.txt2Price = new System.Windows.Forms.TextBox();
            this.txt2Price2 = new System.Windows.Forms.TextBox();
            this.txt2EmployeeH = new System.Windows.Forms.TextBox();
            this.txt2EmployeeH2 = new System.Windows.Forms.TextBox();
            this.txt2SSNH = new System.Windows.Forms.TextBox();
            this.txt2SSNH2 = new System.Windows.Forms.TextBox();
            this.txt2Wage = new System.Windows.Forms.TextBox();
            this.txt2Wage2 = new System.Windows.Forms.TextBox();
            this.txt2Hour = new System.Windows.Forms.TextBox();
            this.txt2Hour2 = new System.Windows.Forms.TextBox();
            this.txtSalaryTotal = new System.Windows.Forms.TextBox();
            this.btnHours = new System.Windows.Forms.Button();
            this.txtCheckSal = new System.Windows.Forms.TextBox();
            this.txtCheckInvoice = new System.Windows.Forms.TextBox();
            this.txtCheckHourly = new System.Windows.Forms.TextBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.grpLabels = new System.Windows.Forms.GroupBox();
            this.grpLabels.SuspendLayout();
            this.SuspendLayout();
            // 
            // txtEmployeeS
            // 
            this.txtEmployeeS.Enabled = false;
            this.txtEmployeeS.Location = new System.Drawing.Point(12, 62);
            this.txtEmployeeS.Name = "txtEmployeeS";
            this.txtEmployeeS.Size = new System.Drawing.Size(121, 20);
            this.txtEmployeeS.TabIndex = 1;
            this.txtEmployeeS.Visible = false;
            // 
            // txtEmployeeH
            // 
            this.txtEmployeeH.Enabled = false;
            this.txtEmployeeH.Location = new System.Drawing.Point(287, 62);
            this.txtEmployeeH.Name = "txtEmployeeH";
            this.txtEmployeeH.Size = new System.Drawing.Size(121, 20);
            this.txtEmployeeH.TabIndex = 2;
            this.txtEmployeeH.Visible = false;
            this.txtEmployeeH.TextChanged += new System.EventHandler(this.txtEmployeeH_TextChanged);
            // 
            // txtInvoice
            // 
            this.txtInvoice.Enabled = false;
            this.txtInvoice.Location = new System.Drawing.Point(151, 62);
            this.txtInvoice.Name = "txtInvoice";
            this.txtInvoice.Size = new System.Drawing.Size(121, 20);
            this.txtInvoice.TabIndex = 3;
            this.txtInvoice.Visible = false;
            this.txtInvoice.TextChanged += new System.EventHandler(this.txtInvoice_TextChanged);
            // 
            // lbl1
            // 
            this.lbl1.AutoSize = true;
            this.lbl1.Location = new System.Drawing.Point(6, 16);
            this.lbl1.Name = "lbl1";
            this.lbl1.Size = new System.Drawing.Size(140, 13);
            this.lbl1.TabIndex = 5;
            this.lbl1.Text = "Employee Name / Invoice #";
            this.lbl1.Visible = false;
            // 
            // btnPrint
            // 
            this.btnPrint.Location = new System.Drawing.Point(151, 271);
            this.btnPrint.Name = "btnPrint";
            this.btnPrint.Size = new System.Drawing.Size(124, 73);
            this.btnPrint.TabIndex = 6;
            this.btnPrint.Text = "Print";
            this.btnPrint.UseVisualStyleBackColor = true;
            this.btnPrint.Click += new System.EventHandler(this.btnPrint_Click);
            // 
            // txtSSNS
            // 
            this.txtSSNS.Enabled = false;
            this.txtSSNS.Location = new System.Drawing.Point(12, 88);
            this.txtSSNS.Name = "txtSSNS";
            this.txtSSNS.Size = new System.Drawing.Size(121, 20);
            this.txtSSNS.TabIndex = 7;
            this.txtSSNS.Visible = false;
            // 
            // txtSSNH
            // 
            this.txtSSNH.Enabled = false;
            this.txtSSNH.Location = new System.Drawing.Point(287, 88);
            this.txtSSNH.Name = "txtSSNH";
            this.txtSSNH.Size = new System.Drawing.Size(121, 20);
            this.txtSSNH.TabIndex = 8;
            this.txtSSNH.Visible = false;
            // 
            // txtInvoiceQuan
            // 
            this.txtInvoiceQuan.Enabled = false;
            this.txtInvoiceQuan.Location = new System.Drawing.Point(151, 88);
            this.txtInvoiceQuan.Name = "txtInvoiceQuan";
            this.txtInvoiceQuan.Size = new System.Drawing.Size(121, 20);
            this.txtInvoiceQuan.TabIndex = 9;
            this.txtInvoiceQuan.Visible = false;
            this.txtInvoiceQuan.TextChanged += new System.EventHandler(this.txtInvoiceQuan_TextChanged);
            // 
            // lbl2
            // 
            this.lbl2.AutoSize = true;
            this.lbl2.Location = new System.Drawing.Point(6, 42);
            this.lbl2.Name = "lbl2";
            this.lbl2.Size = new System.Drawing.Size(73, 13);
            this.lbl2.TabIndex = 10;
            this.lbl2.Text = "SSN/Quantity";
            this.lbl2.Visible = false;
            // 
            // txtSalary
            // 
            this.txtSalary.Enabled = false;
            this.txtSalary.Location = new System.Drawing.Point(12, 117);
            this.txtSalary.Name = "txtSalary";
            this.txtSalary.Size = new System.Drawing.Size(121, 20);
            this.txtSalary.TabIndex = 11;
            this.txtSalary.Visible = false;
            // 
            // txtWage
            // 
            this.txtWage.Enabled = false;
            this.txtWage.Location = new System.Drawing.Point(287, 114);
            this.txtWage.Name = "txtWage";
            this.txtWage.Size = new System.Drawing.Size(121, 20);
            this.txtWage.TabIndex = 12;
            this.txtWage.Visible = false;
            // 
            // txtPartDesc
            // 
            this.txtPartDesc.Enabled = false;
            this.txtPartDesc.Location = new System.Drawing.Point(151, 114);
            this.txtPartDesc.Name = "txtPartDesc";
            this.txtPartDesc.Size = new System.Drawing.Size(121, 20);
            this.txtPartDesc.TabIndex = 13;
            this.txtPartDesc.Visible = false;
            // 
            // lbl3
            // 
            this.lbl3.AutoSize = true;
            this.lbl3.Location = new System.Drawing.Point(6, 69);
            this.lbl3.Name = "lbl3";
            this.lbl3.Size = new System.Drawing.Size(128, 13);
            this.lbl3.TabIndex = 14;
            this.lbl3.Text = "Salary/Wage/Description";
            this.lbl3.Visible = false;
            // 
            // txtHour
            // 
            this.txtHour.Enabled = false;
            this.txtHour.Location = new System.Drawing.Point(287, 143);
            this.txtHour.Name = "txtHour";
            this.txtHour.Size = new System.Drawing.Size(121, 20);
            this.txtHour.TabIndex = 16;
            this.txtHour.Visible = false;
            // 
            // txtUnitPrice
            // 
            this.txtUnitPrice.Enabled = false;
            this.txtUnitPrice.Location = new System.Drawing.Point(151, 143);
            this.txtUnitPrice.Name = "txtUnitPrice";
            this.txtUnitPrice.Size = new System.Drawing.Size(121, 20);
            this.txtUnitPrice.TabIndex = 17;
            this.txtUnitPrice.Visible = false;
            // 
            // lbl4
            // 
            this.lbl4.AutoSize = true;
            this.lbl4.Location = new System.Drawing.Point(6, 95);
            this.lbl4.Name = "lbl4";
            this.lbl4.Size = new System.Drawing.Size(86, 13);
            this.lbl4.TabIndex = 18;
            this.lbl4.Text = "Hours/Unit Price";
            this.lbl4.Visible = false;
            // 
            // radSalary
            // 
            this.radSalary.AutoSize = true;
            this.radSalary.Location = new System.Drawing.Point(37, 16);
            this.radSalary.Name = "radSalary";
            this.radSalary.Size = new System.Drawing.Size(54, 17);
            this.radSalary.TabIndex = 20;
            this.radSalary.TabStop = true;
            this.radSalary.Text = "Salary";
            this.radSalary.UseVisualStyleBackColor = true;
            this.radSalary.CheckedChanged += new System.EventHandler(this.radSalary_CheckedChanged);
            // 
            // radInvoice
            // 
            this.radInvoice.AutoSize = true;
            this.radInvoice.Location = new System.Drawing.Point(172, 16);
            this.radInvoice.Name = "radInvoice";
            this.radInvoice.Size = new System.Drawing.Size(60, 17);
            this.radInvoice.TabIndex = 21;
            this.radInvoice.TabStop = true;
            this.radInvoice.Text = "Invoice";
            this.radInvoice.UseVisualStyleBackColor = true;
            this.radInvoice.CheckedChanged += new System.EventHandler(this.radInvoice_CheckedChanged);
            // 
            // radHourly
            // 
            this.radHourly.AutoSize = true;
            this.radHourly.Location = new System.Drawing.Point(318, 16);
            this.radHourly.Name = "radHourly";
            this.radHourly.Size = new System.Drawing.Size(55, 17);
            this.radHourly.TabIndex = 22;
            this.radHourly.TabStop = true;
            this.radHourly.Text = "Hourly";
            this.radHourly.UseVisualStyleBackColor = true;
            this.radHourly.CheckedChanged += new System.EventHandler(this.radHourly_CheckedChanged);
            // 
            // btnSalary
            // 
            this.btnSalary.Enabled = false;
            this.btnSalary.Location = new System.Drawing.Point(12, 192);
            this.btnSalary.Name = "btnSalary";
            this.btnSalary.Size = new System.Drawing.Size(124, 73);
            this.btnSalary.TabIndex = 23;
            this.btnSalary.Text = "Save | Salary";
            this.btnSalary.UseVisualStyleBackColor = true;
            this.btnSalary.Visible = false;
            this.btnSalary.Click += new System.EventHandler(this.btnSalary_Click);
            // 
            // btnInvoice
            // 
            this.btnInvoice.Enabled = false;
            this.btnInvoice.Location = new System.Drawing.Point(151, 192);
            this.btnInvoice.Name = "btnInvoice";
            this.btnInvoice.Size = new System.Drawing.Size(124, 73);
            this.btnInvoice.TabIndex = 24;
            this.btnInvoice.Text = "Save | Invoice";
            this.btnInvoice.UseVisualStyleBackColor = true;
            this.btnInvoice.Visible = false;
            this.btnInvoice.Click += new System.EventHandler(this.btnHourly_Click);
            // 
            // txt2EmployeeS
            // 
            this.txt2EmployeeS.Location = new System.Drawing.Point(1005, 862);
            this.txt2EmployeeS.Name = "txt2EmployeeS";
            this.txt2EmployeeS.Size = new System.Drawing.Size(10, 20);
            this.txt2EmployeeS.TabIndex = 25;
            this.txt2EmployeeS.Visible = false;
            // 
            // txt2EmployeeS2
            // 
            this.txt2EmployeeS2.Location = new System.Drawing.Point(1768, 435);
            this.txt2EmployeeS2.Name = "txt2EmployeeS2";
            this.txt2EmployeeS2.Size = new System.Drawing.Size(10, 20);
            this.txt2EmployeeS2.TabIndex = 26;
            // 
            // txt2SSNS
            // 
            this.txt2SSNS.Location = new System.Drawing.Point(1776, 443);
            this.txt2SSNS.Name = "txt2SSNS";
            this.txt2SSNS.Size = new System.Drawing.Size(10, 20);
            this.txt2SSNS.TabIndex = 27;
            // 
            // txt2SSNS2
            // 
            this.txt2SSNS2.Location = new System.Drawing.Point(1784, 451);
            this.txt2SSNS2.Name = "txt2SSNS2";
            this.txt2SSNS2.Size = new System.Drawing.Size(10, 20);
            this.txt2SSNS2.TabIndex = 28;
            // 
            // txt2Salary
            // 
            this.txt2Salary.Location = new System.Drawing.Point(1792, 459);
            this.txt2Salary.Name = "txt2Salary";
            this.txt2Salary.Size = new System.Drawing.Size(10, 20);
            this.txt2Salary.TabIndex = 29;
            // 
            // txt2Salary2
            // 
            this.txt2Salary2.Location = new System.Drawing.Point(1800, 467);
            this.txt2Salary2.Name = "txt2Salary2";
            this.txt2Salary2.Size = new System.Drawing.Size(10, 20);
            this.txt2Salary2.TabIndex = 30;
            // 
            // txt2Invoice
            // 
            this.txt2Invoice.Location = new System.Drawing.Point(1808, 475);
            this.txt2Invoice.Name = "txt2Invoice";
            this.txt2Invoice.Size = new System.Drawing.Size(10, 20);
            this.txt2Invoice.TabIndex = 31;
            // 
            // txt2Invoice2
            // 
            this.txt2Invoice2.Location = new System.Drawing.Point(1816, 483);
            this.txt2Invoice2.Name = "txt2Invoice2";
            this.txt2Invoice2.Size = new System.Drawing.Size(10, 20);
            this.txt2Invoice2.TabIndex = 32;
            // 
            // txt2Quan
            // 
            this.txt2Quan.Location = new System.Drawing.Point(1824, 491);
            this.txt2Quan.Name = "txt2Quan";
            this.txt2Quan.Size = new System.Drawing.Size(10, 20);
            this.txt2Quan.TabIndex = 33;
            // 
            // txt2Quan2
            // 
            this.txt2Quan2.Location = new System.Drawing.Point(1832, 499);
            this.txt2Quan2.Name = "txt2Quan2";
            this.txt2Quan2.Size = new System.Drawing.Size(10, 20);
            this.txt2Quan2.TabIndex = 34;
            // 
            // txt2Part
            // 
            this.txt2Part.Location = new System.Drawing.Point(1840, 507);
            this.txt2Part.Name = "txt2Part";
            this.txt2Part.Size = new System.Drawing.Size(10, 20);
            this.txt2Part.TabIndex = 35;
            // 
            // txt2Part2
            // 
            this.txt2Part2.Location = new System.Drawing.Point(1848, 515);
            this.txt2Part2.Name = "txt2Part2";
            this.txt2Part2.Size = new System.Drawing.Size(10, 20);
            this.txt2Part2.TabIndex = 36;
            // 
            // txt2Price
            // 
            this.txt2Price.Location = new System.Drawing.Point(1856, 523);
            this.txt2Price.Name = "txt2Price";
            this.txt2Price.Size = new System.Drawing.Size(10, 20);
            this.txt2Price.TabIndex = 37;
            // 
            // txt2Price2
            // 
            this.txt2Price2.Location = new System.Drawing.Point(1864, 531);
            this.txt2Price2.Name = "txt2Price2";
            this.txt2Price2.Size = new System.Drawing.Size(10, 20);
            this.txt2Price2.TabIndex = 38;
            // 
            // txt2EmployeeH
            // 
            this.txt2EmployeeH.Location = new System.Drawing.Point(1872, 539);
            this.txt2EmployeeH.Name = "txt2EmployeeH";
            this.txt2EmployeeH.Size = new System.Drawing.Size(10, 20);
            this.txt2EmployeeH.TabIndex = 39;
            // 
            // txt2EmployeeH2
            // 
            this.txt2EmployeeH2.Location = new System.Drawing.Point(1880, 547);
            this.txt2EmployeeH2.Name = "txt2EmployeeH2";
            this.txt2EmployeeH2.Size = new System.Drawing.Size(10, 20);
            this.txt2EmployeeH2.TabIndex = 40;
            // 
            // txt2SSNH
            // 
            this.txt2SSNH.Location = new System.Drawing.Point(1888, 555);
            this.txt2SSNH.Name = "txt2SSNH";
            this.txt2SSNH.Size = new System.Drawing.Size(10, 20);
            this.txt2SSNH.TabIndex = 41;
            // 
            // txt2SSNH2
            // 
            this.txt2SSNH2.Location = new System.Drawing.Point(1896, 563);
            this.txt2SSNH2.Name = "txt2SSNH2";
            this.txt2SSNH2.Size = new System.Drawing.Size(10, 20);
            this.txt2SSNH2.TabIndex = 42;
            // 
            // txt2Wage
            // 
            this.txt2Wage.Location = new System.Drawing.Point(1904, 571);
            this.txt2Wage.Name = "txt2Wage";
            this.txt2Wage.Size = new System.Drawing.Size(10, 20);
            this.txt2Wage.TabIndex = 43;
            // 
            // txt2Wage2
            // 
            this.txt2Wage2.Location = new System.Drawing.Point(1912, 579);
            this.txt2Wage2.Name = "txt2Wage2";
            this.txt2Wage2.Size = new System.Drawing.Size(10, 20);
            this.txt2Wage2.TabIndex = 44;
            // 
            // txt2Hour
            // 
            this.txt2Hour.Location = new System.Drawing.Point(1920, 587);
            this.txt2Hour.Name = "txt2Hour";
            this.txt2Hour.Size = new System.Drawing.Size(10, 20);
            this.txt2Hour.TabIndex = 45;
            // 
            // txt2Hour2
            // 
            this.txt2Hour2.Location = new System.Drawing.Point(1928, 595);
            this.txt2Hour2.Name = "txt2Hour2";
            this.txt2Hour2.Size = new System.Drawing.Size(10, 20);
            this.txt2Hour2.TabIndex = 46;
            // 
            // txtSalaryTotal
            // 
            this.txtSalaryTotal.Location = new System.Drawing.Point(1936, 603);
            this.txtSalaryTotal.Name = "txtSalaryTotal";
            this.txtSalaryTotal.Size = new System.Drawing.Size(10, 20);
            this.txtSalaryTotal.TabIndex = 47;
            // 
            // btnHours
            // 
            this.btnHours.Enabled = false;
            this.btnHours.Location = new System.Drawing.Point(287, 192);
            this.btnHours.Name = "btnHours";
            this.btnHours.Size = new System.Drawing.Size(121, 73);
            this.btnHours.TabIndex = 48;
            this.btnHours.Text = "Save | Hourly";
            this.btnHours.UseVisualStyleBackColor = true;
            this.btnHours.Visible = false;
            this.btnHours.Click += new System.EventHandler(this.btnHours_Click);
            // 
            // txtCheckSal
            // 
            this.txtCheckSal.Location = new System.Drawing.Point(330, 883);
            this.txtCheckSal.Name = "txtCheckSal";
            this.txtCheckSal.Size = new System.Drawing.Size(10, 20);
            this.txtCheckSal.TabIndex = 49;
            // 
            // txtCheckInvoice
            // 
            this.txtCheckInvoice.Location = new System.Drawing.Point(449, 883);
            this.txtCheckInvoice.Name = "txtCheckInvoice";
            this.txtCheckInvoice.Size = new System.Drawing.Size(10, 20);
            this.txtCheckInvoice.TabIndex = 50;
            // 
            // txtCheckHourly
            // 
            this.txtCheckHourly.Location = new System.Drawing.Point(606, 883);
            this.txtCheckHourly.Name = "txtCheckHourly";
            this.txtCheckHourly.Size = new System.Drawing.Size(10, 20);
            this.txtCheckHourly.TabIndex = 51;
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(734, 883);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(10, 20);
            this.textBox1.TabIndex = 52;
            // 
            // grpLabels
            // 
            this.grpLabels.Controls.Add(this.lbl1);
            this.grpLabels.Controls.Add(this.lbl2);
            this.grpLabels.Controls.Add(this.lbl3);
            this.grpLabels.Controls.Add(this.lbl4);
            this.grpLabels.Location = new System.Drawing.Point(427, 47);
            this.grpLabels.Name = "grpLabels";
            this.grpLabels.Size = new System.Drawing.Size(148, 116);
            this.grpLabels.TabIndex = 53;
            this.grpLabels.TabStop = false;
            this.grpLabels.Visible = false;
            // 
            // txt2Hourr
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(579, 348);
            this.Controls.Add(this.grpLabels);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.txtCheckHourly);
            this.Controls.Add(this.txtCheckInvoice);
            this.Controls.Add(this.txtCheckSal);
            this.Controls.Add(this.btnHours);
            this.Controls.Add(this.txtSalaryTotal);
            this.Controls.Add(this.txt2Hour2);
            this.Controls.Add(this.txt2Hour);
            this.Controls.Add(this.txt2Wage2);
            this.Controls.Add(this.txt2Wage);
            this.Controls.Add(this.txt2SSNH2);
            this.Controls.Add(this.txt2SSNH);
            this.Controls.Add(this.txt2EmployeeH2);
            this.Controls.Add(this.txt2EmployeeH);
            this.Controls.Add(this.txt2Price2);
            this.Controls.Add(this.txt2Price);
            this.Controls.Add(this.txt2Part2);
            this.Controls.Add(this.txt2Part);
            this.Controls.Add(this.txt2Quan2);
            this.Controls.Add(this.txt2Quan);
            this.Controls.Add(this.txt2Invoice2);
            this.Controls.Add(this.txt2Invoice);
            this.Controls.Add(this.txt2Salary2);
            this.Controls.Add(this.txt2Salary);
            this.Controls.Add(this.txt2SSNS2);
            this.Controls.Add(this.txt2SSNS);
            this.Controls.Add(this.txt2EmployeeS2);
            this.Controls.Add(this.txt2EmployeeS);
            this.Controls.Add(this.btnInvoice);
            this.Controls.Add(this.btnSalary);
            this.Controls.Add(this.radHourly);
            this.Controls.Add(this.radInvoice);
            this.Controls.Add(this.radSalary);
            this.Controls.Add(this.txtUnitPrice);
            this.Controls.Add(this.txtHour);
            this.Controls.Add(this.txtPartDesc);
            this.Controls.Add(this.txtWage);
            this.Controls.Add(this.txtSalary);
            this.Controls.Add(this.txtInvoiceQuan);
            this.Controls.Add(this.txtSSNH);
            this.Controls.Add(this.txtSSNS);
            this.Controls.Add(this.btnPrint);
            this.Controls.Add(this.txtInvoice);
            this.Controls.Add(this.txtEmployeeH);
            this.Controls.Add(this.txtEmployeeS);
            this.Name = "txt2Hourr";
            this.Text = "CashFlow";
            this.Load += new System.EventHandler(this.frmMain);
            this.grpLabels.ResumeLayout(false);
            this.grpLabels.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.TextBox txtEmployeeS;
        private System.Windows.Forms.TextBox txtEmployeeH;
        private System.Windows.Forms.TextBox txtInvoice;
        private System.Windows.Forms.Label lbl1;
        private System.Windows.Forms.Button btnPrint;
        private System.Windows.Forms.TextBox txtSSNS;
        private System.Windows.Forms.TextBox txtSSNH;
        private System.Windows.Forms.TextBox txtInvoiceQuan;
        private System.Windows.Forms.Label lbl2;
        private System.Windows.Forms.TextBox txtSalary;
        private System.Windows.Forms.TextBox txtWage;
        private System.Windows.Forms.TextBox txtPartDesc;
        private System.Windows.Forms.Label lbl3;
        private System.Windows.Forms.TextBox txtUnitPrice;
        private System.Windows.Forms.Label lbl4;
        private System.Windows.Forms.TextBox txtHour;
        private System.Windows.Forms.RadioButton radSalary;
        private System.Windows.Forms.RadioButton radInvoice;
        private System.Windows.Forms.RadioButton radHourly;
        private System.Windows.Forms.Button btnSalary;
        private System.Windows.Forms.Button btnInvoice;
        private System.Windows.Forms.TextBox txt2EmployeeS;
        private System.Windows.Forms.TextBox txt2EmployeeS2;
        private System.Windows.Forms.TextBox txt2SSNS;
        private System.Windows.Forms.TextBox txt2SSNS2;
        private System.Windows.Forms.TextBox txt2Salary;
        private System.Windows.Forms.TextBox txt2Salary2;
        private System.Windows.Forms.TextBox txt2Invoice;
        private System.Windows.Forms.TextBox txt2Invoice2;
        private System.Windows.Forms.TextBox txt2Quan;
        private System.Windows.Forms.TextBox txt2Quan2;
        private System.Windows.Forms.TextBox txt2Part;
        private System.Windows.Forms.TextBox txt2Part2;
        private System.Windows.Forms.TextBox txt2Price;
        private System.Windows.Forms.TextBox txt2Price2;
        private System.Windows.Forms.TextBox txt2EmployeeH;
        private System.Windows.Forms.TextBox txt2EmployeeH2;
        private System.Windows.Forms.TextBox txt2SSNH;
        private System.Windows.Forms.TextBox txt2SSNH2;
        private System.Windows.Forms.TextBox txt2Wage;
        private System.Windows.Forms.TextBox txt2Wage2;
        private System.Windows.Forms.TextBox txt2Hour;
        private System.Windows.Forms.TextBox txt2Hour2;
        private System.Windows.Forms.TextBox txtSalaryTotal;
        private System.Windows.Forms.Button btnHours;
        private System.Windows.Forms.TextBox txtCheckSal;
        private System.Windows.Forms.TextBox txtCheckInvoice;
        private System.Windows.Forms.TextBox txtCheckHourly;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.GroupBox grpLabels;
    }
}

